# Idiomas em Foco — versão 2

Substitua os arquivos antigos por `index.html`, `style.css` e `script.js`.

No GitHub Pages, mantenha:
- Branch: `main`
- Folder: `/ (root)`

Depois faça o commit e aguarde a publicação.

O arquivo `script.js` concentra as frases e questões para facilitar futuras ampliações.
