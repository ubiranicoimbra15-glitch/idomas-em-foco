const CATEGORIES=[
{id:"punctuation",title:"Pontuação",desc:"Sinais e organização"},
{id:"spelling",title:"Ortografia",desc:"Grafia fora da norma"},
{id:"slang",title:"Gíria",desc:"Vocabulário informal"},
{id:"number",title:"Número → letra",desc:"Número com valor sonoro"},
{id:"abbreviation",title:"Abreviação",desc:"Forma encurtada"},
{id:"reduction",title:"Redução",desc:"Palavra reduzida"}];

const PHRASES=[
["pt","Oi, vc vai hj? Tô esperando!!!",["abbreviation","reduction","punctuation"]],
["pt","Mano, isso foi mto bom kkk",["slang","abbreviation","reduction"]],
["pt","A gente vai 2moro? rsrs",["number","slang"]],
["pt","Blz, te vejo dps.",["abbreviation","reduction"]],
["pt","Nossa!!! Que notícia top!",["slang","punctuation"]],
["pt","Vc sabe q eu n consigo hj.",["abbreviation","reduction"]],
["pt","Partiu escola? Tô atrasado kkk.",["slang","reduction","punctuation"]],
["pt","Amg, manda o link p/ mim.",["abbreviation","reduction"]],
["pt","Feliz aniversário!!! Tudo de bom pra vc <3",["abbreviation","punctuation"]],
["pt","Tô mto feliz pq passei!",["abbreviation","reduction"]],
["es","Hola, ¿q haces? Estoy esperando.",["abbreviation","punctuation"]],
["es","Tío, esto estuvo súper guay jajaja.",["slang","punctuation"]],
["es","Nos vemos mañana, xfa.",["abbreviation"]],
["es","K tal? Todo bien?",["abbreviation","punctuation"]],
["es","Bro, eso fue brutal jajaj.",["slang","reduction"]],
["es","Te escribo dps, vale?",["reduction","punctuation"]],
["es","Mañana voy a estudiar 2 horas.",["number"]],
["es","Xq no vienes con nosotros?",["abbreviation","punctuation"]],
["es","Estoy mto feliz por ti.",["abbreviation","reduction"]],
["es","Estoy muy cansado, no puedo +.",["abbreviation"]]
].map(x=>({lang:x[0],text:x[1],tags:x[2]}));

const PT=[
["Em “Vc vai hj?”, qual recurso aparece principalmente?",["Gíria","Abreviação","Número substituindo letra","Estrangeirismo","Neologismo"],1],
["Qual frase apresenta redução típica da comunicação digital?",["Estou estudando agora.","Vou para casa depois.","Tô estudando agora.","Estudarei amanhã.","Chegarei cedo."],2],
["Em “A gente vai 2moro?”, o número representa:",["Uma data","Uma pontuação","Um horário","Parte sonora de uma palavra","Uma sigla"],3],
["Qual sinal indica uma pergunta em português?",["!","?",".",":",";"],1],
["“Mano” pode ser, conforme o contexto:",["Gíria","Termo jurídico","Linguagem científica","Sigla","Termo técnico"],0],
["Qual opção está de acordo com a norma-padrão?",["Vc foi ontem?","A gente fomos ontem.","Você foi ontem?","Nós vai amanhã.","Eles foi cedo."],2],
["“Blz” corresponde a:",["Beleza","Brincadeira","Boa leitura","Bastante legal","Bom lugar"],0],
["Qual alternativa apresenta uma abreviação?",["casa","escola","pq","amanhã","livro"],2],
["Na comunicação digital, “kkk” costuma indicar:",["Riso","Dúvida","Tristeza","Pedido","Despedida"],0],
["Estudar a linguagem digital ajuda o aluno a:",["Eliminar toda linguagem informal","Compreender usos e contextos da língua","Evitar tecnologia","Substituir a escrita escolar","Usar apenas abreviações"],1]
].map(x=>({q:x[0],a:x[1],c:x[2]}));

const ES=[
["En “¿q haces?”, “q” funciona como:",["Una abreviación","Un número","Una interjección","Un verbo","Un pronombre"],0],
["¿Qué expresión funciona como saludo?",["Adiós","Hola","Nunca","Después","Porque"],1],
["En “jajaja”, normalmente se expresa:",["Risa","Miedo","Orden","Duda","Silencio"],0],
["¿Cuál palabra puede ser coloquial o juvenil?",["Tío","Diccionario","Biblioteca","Gramática","Oración"],0],
["“Xq” suele representar:",["Aunque","Porque","Cuando","Quién","Quizás"],1],
["¿Cuál oración presenta correctamente una pregunta?",["Que haces!","¿Qué haces?","Qué haces.","¿Qué haces!","Qué haces,"],1],
["En “xfa”, la forma completa es:",["Por favor","Para nada","Por aquí","Por ahora","Para hablar"],0],
["“Guay” puede funcionar como:",["Una expresión coloquial","Un pronombre","Un tiempo verbal","Una preposición","Un artículo"],0],
["Estudiar la comunicación digital en español permite:",["Comprender usos lingüísticos en contextos diversos","Eliminar variedades lingüísticas","Evitar el aprendizaje","Usar solo abreviaciones","Dejar de leer"],0],
["¿Cuál opción sigue la norma-padrão del español?",["¿Dónde estás?","Donde estás?","¿Dónde estas.","Dónde estás!","¿dónde estas?"],0]
].map(x=>({q:x[0],a:x[1],c:x[2]}));

let score=+localStorage.if_score||0,right=+localStorage.if_right||0,wrong=+localStorage.if_wrong||0,acts=+localStorage.if_acts||0;
let filter="all",pidx=0,checked=false,qi={pt:0,es:0},ans={pt:{},es:{}};
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
function save(){localStorage.if_score=score;localStorage.if_right=right;localStorage.if_wrong=wrong;localStorage.if_acts=acts}
function stats(){$("#score").textContent=score;$("#right").textContent=right;$("#wrong").textContent=wrong;$("#acts").textContent=acts}
function result(ok){acts++;ok? (right++,score+=10):wrong++;save();stats()}
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function arr(){return PHRASES.filter(p=>filter==="all"||p.lang===filter)}
function renderList(){let a=arr();$("#phraseList").innerHTML=a.map((p,i)=>`<button class="phrase-btn ${i===pidx?"active":""}" data-i="${i}"><small>${p.lang==="pt"?"Português":"Español"} • ${String(PHRASES.indexOf(p)+1).padStart(2,"0")}</small><span>${esc(p.text)}</span></button>`).join("");$$(".phrase-btn").forEach(b=>b.onclick=()=>{pidx=+b.dataset.i;checked=false;renderList();renderPhrase()})}
function renderPhrase(){let p=arr()[pidx];if(!p)return;$("#lang").textContent=p.lang==="pt"?"PORTUGUÊS":"ESPAÑOL";$("#num").textContent=`Frase ${String(PHRASES.indexOf(p)+1).padStart(2,"0")}`;$("#phrase").textContent=p.text;$("#cats").innerHTML=CATEGORIES.map(c=>`<div class="cat"><input id="${c.id}" type="checkbox"><label for="${c.id}"><b>${c.title}</b><span>${c.desc}</span></label></div>`).join("");$("#feedback").innerHTML=""}
function checkPhrase(){let p=arr()[pidx],sel=CATEGORIES.filter(c=>$("#"+c.id).checked).map(c=>c.id).sort(),tar=[...p.tags].sort(),ok=JSON.stringify(sel)===JSON.stringify(tar);if(checked)return;checked=true;result(ok);$("#feedback").className="feedback "+(ok?"good":"bad");$("#feedback").textContent=ok?"✓ Análise correta.":`✕ Revise. Esperado: ${p.tags.map(t=>CATEGORIES.find(c=>c.id===t).title).join(", ")}.`}
function nextPhrase(){pidx=(pidx+1)%arr().length;checked=false;renderList();renderPhrase()}
function quiz(kind){let data=kind==="pt"?PT:ES,idx=qi[kind],a=ans[kind],host=$(kind==="pt"?"#ptcard":"#escard"),pr=$(kind==="pt"?"#ptp":"#esp"),bar=$(kind==="pt"?"#ptbar":"#esbar");pr.textContent=idx<10?`${idx+1}/10`:"10/10";bar.style.width=`${Math.max(10,idx*10)}%`;if(idx>=10){let n=data.filter((q,i)=>a[i]===q.c).length;host.innerHTML=`<div class="quiz result"><small>RESULTADO</small><h3>${n}/10</h3><p>Quiz concluído.</p><button class="primary" onclick="restart('${kind}')">Refazer quiz</button></div>`;bar.style.width="100%";return}let q=data[idx],sel=a[idx];host.innerHTML=`<div class="quiz"><div class="quiz-meta"><span>${kind==="pt"?"PORTUGUÊS":"ESPAÑOL"}</span><span>Questão ${idx+1} de 10</span></div><div class="question">${esc(q.q)}</div>${q.a.map((x,i)=>`<label class="option ${sel!==undefined&&i===q.c?"correct":""} ${sel!==undefined&&sel===i&&i!==q.c?"wrong":""}"><input type="radio" name="${kind}" value="${i}" ${sel===i?"checked":""} ${sel!==undefined?"disabled":""}>${esc(x)}</label>`).join("")}<div class="quiz-foot">${sel===undefined?"Escolha uma alternativa.":sel===q.c?"✓ Resposta correta.":"✕ Resposta incorreta. Correta: "+q.a[q.c]}</div><div class="quiz-nav"><button onclick="back('${kind}')">← Anterior</button><button class="primary" onclick="next('${kind}')">${idx===9?"Finalizar":"Próxima →"}</button></div></div>`;host.querySelectorAll("input").forEach(i=>i.onchange=()=>answer(kind,+i.value))}
function answer(k,v){let d=k==="pt"?PT:ES,i=qi[k];if(ans[k][i]!==undefined)return;ans[k][i]=v;result(v===d[i].c);quiz(k)}
function next(k){if(ans[k][qi[k]]===undefined)return;if(qi[k]<10)qi[k]++;quiz(k)}
function back(k){if(qi[k]>0)qi[k]--;quiz(k)}
function restart(k){qi[k]=0;ans[k]={};quiz(k)}
$$(".tabs button").forEach(b=>b.onclick=()=>{$$(".tabs button").forEach(x=>x.classList.remove("active"));b.classList.add("active");$$(".page").forEach(x=>x.classList.remove("active"));$("#"+b.dataset.tab).classList.add("active")});
$$(".filters button").forEach(b=>b.onclick=()=>{$$(".filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");filter=b.dataset.filter;pidx=0;renderList();renderPhrase()});
$("#check").onclick=checkPhrase;$("#next").onclick=nextPhrase;
$("#reset").onclick=()=>{if(confirm("Reiniciar pontuação e progresso?")){score=right=wrong=acts=0;qi={pt:0,es:0};ans={pt:{},es:{}};save();stats();quiz("pt");quiz("es")}};
stats();renderList();renderPhrase();quiz("pt");quiz("es");